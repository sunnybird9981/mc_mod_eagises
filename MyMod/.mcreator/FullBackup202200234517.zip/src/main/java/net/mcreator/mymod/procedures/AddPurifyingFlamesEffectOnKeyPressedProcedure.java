package net.mcreator.mymod.procedures;

import net.minecraftforge.items.CapabilityItemHandler;

import net.minecraft.util.text.StringTextComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.EnchantmentHelper;

import net.mcreator.mymod.enchantment.AegisesEnchantment;
import net.mcreator.mymod.MymodModVariables;
import net.mcreator.mymod.MymodMod;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;

public class AddPurifyingFlamesEffectOnKeyPressedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MymodMod.LOGGER.warn("Failed to load dependency entity for procedure AddPurifyingFlamesEffectOnKeyPressed!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		double slotindex = 0;
		if ((EnchantmentHelper.getEnchantmentLevel(AegisesEnchantment.enchantment,
				((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)) != 0)) {
			if ((entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MymodModVariables.PlayerVariables())).purifyingFlamesStat < 2) {
				{
					double _setval = ((entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MymodModVariables.PlayerVariables())).purifyingFlamesStat + 1);
					entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.purifyingFlamesStat = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if (entity instanceof PlayerEntity && !entity.world.isRemote()) {
				((PlayerEntity) entity).sendStatusMessage(
						new StringTextComponent(("PurifyingFlamesStat : " + (entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new MymodModVariables.PlayerVariables())).purifyingFlamesStat)),
						(false));
			}
		} else {
			for (int index0 = 0; index0 < (int) (9); index0++) {
				if ((EnchantmentHelper.getEnchantmentLevel(AegisesEnchantment.enchantment, (new Object() {
					public ItemStack getItemStack(int sltid, Entity entity) {
						AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
						entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).copy());
						});
						return _retval.get();
					}
				}.getItemStack((int) (slotindex), entity))) != 0)) {
					if ((entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MymodModVariables.PlayerVariables())).purifyingFlamesStat < 2) {
						{
							double _setval = ((entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new MymodModVariables.PlayerVariables())).purifyingFlamesStat + 1);
							entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.purifyingFlamesStat = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
					}
					if (entity instanceof PlayerEntity && !entity.world.isRemote()) {
						((PlayerEntity) entity).sendStatusMessage(new StringTextComponent(
								("PurifyingFlamesStat : " + (entity.getCapability(MymodModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new MymodModVariables.PlayerVariables())).purifyingFlamesStat)),
								(false));
					}
					break;
				}
				slotindex = (slotindex + 1);
			}
		}
	}
}
