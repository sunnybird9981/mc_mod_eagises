package net.mcreator.mymod.procedures;

import net.minecraftforge.items.CapabilityItemHandler;

import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.EnchantmentHelper;

import net.mcreator.mymod.enchantment.AegisesEnchantment;
import net.mcreator.mymod.MymodModVariables;
import net.mcreator.mymod.MymodMod;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;

public class ReverseForesightEffectOnKeyPressedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MymodMod.LOGGER.warn("Failed to load dependency world for procedure ReverseForesightEffectOnKeyPressed!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MymodMod.LOGGER.warn("Failed to load dependency entity for procedure ReverseForesightEffectOnKeyPressed!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		Entity entity = (Entity) dependencies.get("entity");
		double slotindex = 0;
		if ((EnchantmentHelper.getEnchantmentLevel(AegisesEnchantment.enchantment,
				((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)) != 0)) {
			if (MymodModVariables.MapVariables.get(world).foresightStat > 0) {
				MymodModVariables.MapVariables.get(world).foresightStat = (MymodModVariables.MapVariables.get(world).foresightStat - 1);
				MymodModVariables.MapVariables.get(world).syncData(world);
			}
			if (entity instanceof PlayerEntity && !entity.world.isRemote()) {
				((PlayerEntity) entity).sendStatusMessage(
						new StringTextComponent(("ForesightStat : " + MymodModVariables.MapVariables.get(world).foresightStat)), (false));
			}
		} else {
			for (int index0 = 0; index0 < (int) (9); index0++) {
				if ((EnchantmentHelper.getEnchantmentLevel(AegisesEnchantment.enchantment, (new Object() {
					public ItemStack getItemStack(int sltid, Entity entity) {
						AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
						entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).copy());
						});
						return _retval.get();
					}
				}.getItemStack((int) (slotindex), entity))) != 0)) {
					if (MymodModVariables.MapVariables.get(world).foresightStat > 0) {
						MymodModVariables.MapVariables.get(world).foresightStat = (MymodModVariables.MapVariables.get(world).foresightStat - 1);
						MymodModVariables.MapVariables.get(world).syncData(world);
					}
					if (entity instanceof PlayerEntity && !entity.world.isRemote()) {
						((PlayerEntity) entity).sendStatusMessage(
								new StringTextComponent(("ForesightStat : " + MymodModVariables.MapVariables.get(world).foresightStat)), (false));
					}
					break;
				}
				slotindex = (slotindex + 1);
			}
		}
	}
}
