package net.mcreator.mymod.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.mymod.network.MymodModVariables;
import net.mcreator.mymod.init.MymodModEnchantments;

public class AddPurifyingFlamesEffectOnKeyPressedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double slotindex = 0;
		if (EnchantmentHelper.getItemEnchantmentLevel(MymodModEnchantments.AEGISES.get(), (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)) != 0) {
			if (entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat < 2) {
				{
					MymodModVariables.PlayerVariables _vars = entity.getData(MymodModVariables.PLAYER_VARIABLES);
					_vars.purifyingFlamesStat = entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat + 1;
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(("PurifyingFlamesStat : " + entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat)), false);
		} else {
			for (int index0 = 0; index0 < 9; index0++) {
				if (EnchantmentHelper.getItemEnchantmentLevel(MymodModEnchantments.AEGISES.get(), (new Object() {
					public ItemStack getItemStack(int sltid, Entity entity) {
						if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandler) {
							return _modHandler.getStackInSlot(sltid).copy();
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) slotindex, entity))) != 0) {
					if (entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat < 2) {
						{
							MymodModVariables.PlayerVariables _vars = entity.getData(MymodModVariables.PLAYER_VARIABLES);
							_vars.purifyingFlamesStat = entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat + 1;
							_vars.syncPlayerVariables(entity);
						}
					}
					if (entity instanceof Player _player && !_player.level().isClientSide())
						_player.displayClientMessage(Component.literal(("PurifyingFlamesStat : " + entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat)), false);
					break;
				}
				slotindex = slotindex + 1;
			}
		}
	}
}
