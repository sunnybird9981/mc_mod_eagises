
package net.mcreator.mymod.enchantment;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.tags.ItemTags;

public class AegisesEnchantment extends Enchantment {
	public AegisesEnchantment(EquipmentSlot... slots) {
		super(Enchantment.definition(ItemTags.WEAPON_ENCHANTABLE, 1, 1, Enchantment.dynamicCost(1, 10), Enchantment.dynamicCost(6, 10), 8, EquipmentSlot.MAINHAND));
	}
}
