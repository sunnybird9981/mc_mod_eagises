package net.mcreator.mymod.procedures;

public class ForesightEffectOnEffectActiveTickProcedure {
	public static void execute() {
		double distance = 0;
		double checkdTime = 0;
	}
}
