package net.mcreator.mymod.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.mymod.network.MymodModVariables;
import net.mcreator.mymod.init.MymodModMobEffects;

import javax.annotation.Nullable;

@EventBusSubscriber
public class EffectsStartProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (MymodModVariables.MapVariables.get(world).foresightStat > 1) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MymodModMobEffects.FORESIGHT_EFFECT, 10, 0, false, false));
		}
		if (entity.getData(MymodModVariables.PLAYER_VARIABLES).purifyingFlamesStat > 0) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MymodModMobEffects.PURIFYING_FLAMES, 10, 0, false, false));
		}
	}
}
