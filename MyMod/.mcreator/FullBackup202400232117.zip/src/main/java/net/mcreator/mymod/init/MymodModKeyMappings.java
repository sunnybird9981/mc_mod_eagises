
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymod.init;

import org.lwjgl.glfw.GLFW;

import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.mymod.network.ToggleForesightStatMessage;
import net.mcreator.mymod.network.SubPurifyingFlamesStatMessage;
import net.mcreator.mymod.network.ReverseForesightStatMessage;
import net.mcreator.mymod.network.ClearPotionEffectsMessage;
import net.mcreator.mymod.network.AddPurifyingFlamesStatMessage;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class MymodModKeyMappings {
	public static final KeyMapping TOGGLE_FORESIGHT_STAT = new KeyMapping("key.mymod.toggle_foresight_stat", GLFW.GLFW_KEY_9, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new ToggleForesightStatMessage(0, 0));
				ToggleForesightStatMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping REVERSE_FORESIGHT_STAT = new KeyMapping("key.mymod.reverse_foresight_stat", GLFW.GLFW_KEY_8, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new ReverseForesightStatMessage(0, 0));
				ReverseForesightStatMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping ADD_PURIFYING_FLAMES_STAT = new KeyMapping("key.mymod.add_purifying_flames_stat", GLFW.GLFW_KEY_7, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new AddPurifyingFlamesStatMessage(0, 0));
				AddPurifyingFlamesStatMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping SUB_PURIFYING_FLAMES_STAT = new KeyMapping("key.mymod.sub_purifying_flames_stat", GLFW.GLFW_KEY_6, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new SubPurifyingFlamesStatMessage(0, 0));
				SubPurifyingFlamesStatMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping CLEAR_POTION_EFFECTS = new KeyMapping("key.mymod.clear_potion_effects", GLFW.GLFW_KEY_0, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PacketDistributor.sendToServer(new ClearPotionEffectsMessage(0, 0));
				ClearPotionEffectsMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(TOGGLE_FORESIGHT_STAT);
		event.register(REVERSE_FORESIGHT_STAT);
		event.register(ADD_PURIFYING_FLAMES_STAT);
		event.register(SUB_PURIFYING_FLAMES_STAT);
		event.register(CLEAR_POTION_EFFECTS);
	}

	@EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(ClientTickEvent.Post event) {
			if (Minecraft.getInstance().screen == null) {
				TOGGLE_FORESIGHT_STAT.consumeClick();
				REVERSE_FORESIGHT_STAT.consumeClick();
				ADD_PURIFYING_FLAMES_STAT.consumeClick();
				SUB_PURIFYING_FLAMES_STAT.consumeClick();
				CLEAR_POTION_EFFECTS.consumeClick();
			}
		}
	}
}
