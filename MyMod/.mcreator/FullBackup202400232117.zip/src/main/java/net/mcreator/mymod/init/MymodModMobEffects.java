
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.mymod.potion.PurifyingFlamesMobEffect;
import net.mcreator.mymod.potion.ForesightEffectMobEffect;
import net.mcreator.mymod.MymodMod;

public class MymodModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, MymodMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> FORESIGHT_EFFECT = REGISTRY.register("foresight_effect", () -> new ForesightEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> PURIFYING_FLAMES = REGISTRY.register("purifying_flames", () -> new PurifyingFlamesMobEffect());
}
