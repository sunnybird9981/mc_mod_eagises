
package net.mcreator.mymod.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.mymod.procedures.PurifyingFlamesOnEffectActiveTickProcedure;

public class PurifyingFlamesMobEffect extends MobEffect {
	public PurifyingFlamesMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -26215);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		PurifyingFlamesOnEffectActiveTickProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
		return super.applyEffectTick(entity, amplifier);
	}
}
