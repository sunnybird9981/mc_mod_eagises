
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.core.registries.Registries;

import net.mcreator.mymod.enchantment.AegisesEnchantment;
import net.mcreator.mymod.MymodMod;

public class MymodModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(Registries.ENCHANTMENT, MymodMod.MODID);
	public static final DeferredHolder<Enchantment, Enchantment> AEGISES = REGISTRY.register("aegises", () -> new AegisesEnchantment());
}
