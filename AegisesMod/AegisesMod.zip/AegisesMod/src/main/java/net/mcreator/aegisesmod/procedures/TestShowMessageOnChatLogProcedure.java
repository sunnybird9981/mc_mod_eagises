package net.mcreator.aegisesmod.procedures;

public class TestShowMessageOnChatLogProcedure {
	public static void execute() {
	}
}
