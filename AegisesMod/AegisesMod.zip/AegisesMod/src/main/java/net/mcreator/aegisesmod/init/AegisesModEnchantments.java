
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.aegisesmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.aegisesmod.enchantment.AegisesEnchantment;
import net.mcreator.aegisesmod.AegisesMod;

public class AegisesModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, AegisesMod.MODID);
	public static final RegistryObject<Enchantment> AEGISES = REGISTRY.register("aegises", () -> new AegisesEnchantment());
}
